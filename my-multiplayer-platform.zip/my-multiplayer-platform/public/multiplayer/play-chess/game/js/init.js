////////////////////////////////////////////////////////////
// INIT
////////////////////////////////////////////////////////////
 var stageWidth,stageHeight=0;
 var isLoaded=false;
 
 /*!
 * 
 * DOCUMENT READY
 * 
 */
 $(function() {
	  var resumeAudioContext = function() {
		// handler for fixing suspended audio context in Chrome
		try {
			if (createjs.WebAudioPlugin.context.state === "suspended") {
				createjs.WebAudioPlugin.context.resume();
				// Should only need to fire once
				window.removeEventListener("click", resumeAudioContext);
			}
		} catch (e) {
			// SoundJS context or web audio plugin may not exist
			console.error("There was an error while trying to resume the SoundJS Web Audio context...");
			console.error(e);
		}
	};
	window.addEventListener("click", resumeAudioContext);
	 
	 // Check for running exported on file protocol
	if (window.location.protocol.substr(0, 4) === "file"){
		alert("To install the game just upload folder 'game' to your server. The game won't run locally with some browser like Chrome due to some security mode.");
	}
	 
	 
	 $(window).resize(function(){
		resizeLoaderFunc();
	 });
	 resizeLoaderFunc();
	 checkBrowser();
});

/*!
 * 
 * LOADER RESIZE - This is the function that runs to centeralised loader when resize
 * 
 */
 function resizeLoaderFunc(){
	stageWidth=$(window).width();
	stageHeight=$(window).height();
	
	$('#mainLoader').css('left', checkContentWidth($('#mainLoader')));
	$('#mainLoader').css('top', checkContentHeight($('#mainLoader')));
 }

/*!
 * 
 * BROWSER DETECT - This is the function that runs for browser and feature detection
 * 
 */
var browserSupport=false;
var isTablet;
function checkBrowser(){
	isTablet = (/ipad|android|android 3.0|xoom|sch-i800|playbook|tablet|kindle/i.test(navigator.userAgent.toLowerCase()));
	deviceVer=getDeviceVer();
	
	var canvasEl = document.createElement('canvas');
	if(canvasEl.getContext){ 
	  browserSupport=true;
	}
	
	if(browserSupport){
		if(!isLoaded){
			isLoaded=true;
			
			// ============================================================
			// CHANGED: This line was originally just "initPreload();"
			// Now it calls detectAddScript to check for multiplayer files
			// ============================================================
			detectAddScript(true);
		}
	}else{
		//browser not support
		$('#notSupportHolder').show();
	}
}

// ============================================================
// NEW CODE ADDED BELOW - Multiplayer Detection Functions
// ============================================================

/*!
 * 
 * DETECT MULTIPLAYER - This function checks if multiplayer files exist
 * 
 */
function detectAddScript(addon){
   if(addon){
	   // Note: Using ../ because the game is in a subdirectory (e.g., /connectfour/)
	   // and the multiplayer folder is one level up in /public/multiplayer/
	   if(checkAddScript("../multiplayer/css/socket.css", "../multiplayer/js/socket.js", "../multiplayer/js/socket-app.js", "/socket.io/socket.io.js")){
			doneAddScript();
	   }else{
		   doneAddScript();
	   }
   }else{
	   doneAddScript();
   }
}

/*!
 * 
 * CHECK MULTIPLAYER FILES - This function verifies each multiplayer file exists
 * 
 */
function checkAddScript(styleFile, scriptFile, scriptAppFile, socketFile){
   var styleExist = checkFileExist(styleFile);
   var scriptExist = checkFileExist(scriptFile);
   var scriptAppExist = checkFileExist(scriptAppFile);
   var socketExist = checkFileExist(socketFile);

   if(styleExist && scriptExist && socketExist){
	   // If all files exist, dynamically load them into the page
	   $('head').append('<link rel="stylesheet" type="text/css" href="'+styleFile+'">');
	   $('head').append('<script type="text/javascript" src="'+socketFile+'"></script>');
	   $('head').append('<script type="text/javascript" src="'+scriptFile+'"></script>');
	   $('head').append('<script type="text/javascript" src="'+scriptAppFile+'"></script>');

	   return true;
   }else{
	   return false;
   }
}

/*!
 * 
 * DONE LOADING - This function continues with game initialization
 * 
 */
function doneAddScript(){
	// This was the original function call
	initPreload();
}

/*!
 * 
 * CHECK FILE EXISTS - This function tests if a file is accessible
 * 
 */
function checkFileExist(urlToFile) {
   var response = jQuery.ajax({
	   url: urlToFile,
	   type: 'HEAD',
	   async: false
   }).status;	
   
   return (response != "200") ? false : true;
}
